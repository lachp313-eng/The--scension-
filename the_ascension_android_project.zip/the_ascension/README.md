# THE ASCENSION — local-first RPG prototype

A first functional prototype for a personal medieval self-improvement RPG. It includes four tabs (Home, Challenges, Goals, Stats), six attributes, daily/weekly challenges, difficulty-based XP, custom goals, deadline consequences, a radar chart, save export/import, and local browser storage.

## Current state

- `www/index.html` is the runnable standalone prototype. Open it in a modern browser to test it; it stores progress in that browser's local storage.
- `android/` is an Android Studio project wrapper that loads the app from bundled assets. It is designed to be offline and does not request internet permission.
- This workspace did not have the Android SDK or Gradle installed, so an APK could not be compiled or verified here. Open `android/` in Android Studio, install the Android SDK platform 35 if prompted, then choose **Build > Build APK(s)**. Android Studio will produce the APK under `android/app/build/outputs/apk/`.

## Important prototype notes

- Challenge completion is manually confirmed in this prototype; there is no automatic sensor or wearable verification.
- XP and goal penalties are prototype rules and can be tuned.
- Data is local to the app/browser. Uninstalling or clearing app data may erase it, so use Export Save File for backups.
- The character art is currently a concept-art placeholder used as a background; staged character evolution and equipment unlocks are planned for a later iteration.
